# U1.W2: Thinking About Time Reflection

* How do you manage your time currently?
* Is your current strategy working? If not, why not? 
* What techniques did you look into during this challenge that interested you?
* Can/will you employ any of them? If so, how?
* What is your overall plan for Phase 0 time management?

	• I set a timer and take interval breaks depending on the work and how much I am learning.

	• Most of the time it works, but I feel that I can always do better.

	• Matthew V. posted a handy tool to improve habits called chains.cc. 

	• This tool will improve the way I organize, manage and track my time.

	• I trust the curriculum and I will do all the work in a timely fashion. Also work on the new assignments as soon as they are released. Falling behind is not an option.
	