## 5. Web Basics Assignment and Reflection

##Part 1: Based on the resources you looked at, describe the terms you learned about.

- Browser:
- DNS:
- Domain:
- Internet:
- IP address:
- Web app:
- Web server:
- Website:
- World wide web:


Explain how the internet displays your website after you push your changes.

## Part 2: Reflection
- What 2 new things did you learn about the web?
- How did you feel when you saw your web page live?
- Did you have an "aha" moments or were any concepts solidified?
- Did you find any resources on your own that helped you better understand a topic? If so, please list it.

<!-- Add your reflection here. Remove the comment markers -->