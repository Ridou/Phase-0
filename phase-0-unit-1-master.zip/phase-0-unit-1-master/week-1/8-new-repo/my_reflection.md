## 4. Open Source and Repo Setup  Reflection

* Explain how to create a repository on GitHub and clone the repository to your local computer to a non-technical person
* Describe what open source means
* What do you think about Open Source? Does it make you nervous or protective? Does it feel like utopia?
* Assess the importance of using licenses
* What concepts were solidified in the challenge? Did you have any "aha" moments? What did you struggle with?
* Did you find any resources on your own that helped you better understand a topic? If so, please list it.

- Go to you account on GitHub and click on the repositories tab. On the right click New. Name your repository and add an MIT license if you want to do open source. Once created copy the link on the right bottom of your new repository we will use it soon. Open the command and type pwd to see your current file location. Type cd path (the path that you would like to clone your new repository) now type git remote add URL (past the URL).

- Code made available to everyone and free to redistribute/modify.

- I have mixed feelings about it. I like it for some projects, but there are some projects that should not be open sourced.

- An MIT license could protect you from a lawsuit if you decide to modify, copy, distribute however many times you want. It is important to protect your code if it's unique and valuable.

- I was able to practice forking, cloning, editing, adding, pushing, and committing to git hub. It was a healthy practice. These were all aha moments and it made me more confident working with github.

- Smashing magazine explained better different types of licenses like Apache, GNU, BSD and CC. This resource gave me a better understanding about their similarities and differences.
http://www.smashingmagazine.com/2010/03/24/a-short-guide-to-open-source-and-similar-licenses/