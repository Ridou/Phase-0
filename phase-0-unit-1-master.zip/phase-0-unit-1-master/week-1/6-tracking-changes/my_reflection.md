## Tracking Changes Reflection

- How does tracking and adding changes make developer's lives easier?
- What is a commit?
- What does the HEAD^ argument mean?
- What are the 3 stages of a git change and how do you move a file from to the other?
- Write a handy cheatsheet of the commands you need to commit your changes?
- What is a pull request? Why do you think they are preferred when working with teams?


- Tracking allows the developer to go back to past versions if a bug is encountered and adding changes to GitHub allows many developers to work together.
Making changes

- The last commit made.

- Git directory, working directory, and the staging area.

- First git add . to add the files that were modified, second git commit -m "commit message", the last thing is to push using the remote and branch by git push remote branch.

- Pull request allows others to review the commits pushed. This is essential for teamwork to plan the next commits necessary.