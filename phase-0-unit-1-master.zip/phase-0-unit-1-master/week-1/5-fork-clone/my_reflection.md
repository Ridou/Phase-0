## 2. Github Introduction Reflection

### From Github Introduction Challenge

- Write an explanation of and compare git and GitHub to a non-technical audience.
- Describe what version control is and how GitHub helps with it.
- Why do developers use version control (git)? Does that make sense to you? Why or why not?
- What doesn't make sense? What does?

### From Fork and Clone challenge
- Create your own step-by-step fork and clone instructions for later use
- What struggles did you have setting up git and GitHub? What did you learn in the process?
- Did you have any moments where it all clicked? What clicked?




-   GitHub is a global gateway for distribution of Git commits from your local device.
-   Version control records versions of files over time to be able to recall previous commits.
-   It makes sense to use version control to review changes made, who made the change, why they changed it and/or revert files to their previous state
-   It does not make sense why this website does not have a more seamless social aspect.
-   To fork, click on the Fork button on the top right of the interface and make sure you are logged in. To clone you need to copy the URL on the bottom right and on the command list type "git clone URL" (Make sure it will be cloned to the desktop)
-   I had trouble linking my Sublime text 2 with github. I learned that asking a friend is the best source of information.
-   After using GitHub in intervals I felt more comfortable using the interface. They should pay serious money to DBC to create their tutorial.
