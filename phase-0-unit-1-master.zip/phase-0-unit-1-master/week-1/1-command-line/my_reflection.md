# 1: Command Line Reflection

Write your reflection on a document or by hand on the following questions. Keep track of your answers because you'll be asked to add them to this document in challenge [6: Tracking Changes](../6-tracking-changes).

1. What was the most challenging for you in going through this material?
	Setting up Sublime just how I want it, because I will be using it as my main text editor for a while.
2. Were you able to successfully use all of the commands?
	Yes
3. Can you remember what each of the following does of the top of your head? Write what each does.

-`pwd` = prints working directory

-`ls` = prints files in current dirrectory

-`grep` = search files for lines that match

-`mv` = move or rename files from a directory

-`cd` = go to directory

-`../` = parent of the current directory

-`touch` = add a file or change type

-`mkdir` = make a new folder/directory

-`echo` = print a string

-`less` = *display output one screen at a time

-`rmdir` = remove directory

-`cat` = *concatenate and print the content of files

-`rm` = remove

-`help` = help information

-`exit` = exit terminal