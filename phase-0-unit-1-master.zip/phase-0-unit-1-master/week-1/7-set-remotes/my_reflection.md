# Setting Remotes

- What is a remote?
- How are they set up?
- Summarize the purpose of a remote
- Write a brief workflow (list of commands) on how to fetch changes from Dev Bootcamp's master branch

- A remote is a server repository in which you can pull and push code.

- A remote can be set up by using the command git add remote URL. This will allow to transfer and merge files from github.

- It allows you to fetch and merge repositories to update.

- Workflow
	- First, set up a fork the repo in order to have your own repo on github

	- Second, link remotely your personal repo from github with your local computer using git add remote URL

	- Third, add an upstream in order to fetch updated information from the DevBootCamp's repo by using git add upstream URL

	- Fourth, fetch changes from DevbootCamp master by using the command git fetch upstream master.