# Notes for Numbers and Letters

## Numbers

### Summary
- What does `puts` do?
- What is the difference between float and integer division?

### Try it!

My solution for:

1.  Hours in a year

```ruby
puts "There are" +(24*365).to_s+ "hours in a year."
```

2. Minutes in a decade

```ruby
puts "There are" +(60*24*365*10).to_s+ "minutes in a decade."
```

## Reflection

1. Puts outputs to the console or returns nil

2. Integer stores whole numbers and float stores values with decimal points.