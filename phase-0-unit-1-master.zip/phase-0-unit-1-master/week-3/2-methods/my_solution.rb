# Release 1: Try it out

# 1. Full name greeting: Write a program that asks for a person's first name, then middle, then last. Finally, it should greet the person using their full name.

puts "What is your first name?"
fname = gets.chomp
puts "What is your middle name?"
mname = gets.chomp
puts "What is your last name?"
lname = gets.chomp

puts "Welcome #{fname} #{mname} #{lname} to challenge 2."

# -------------------------------------------
# 2. Bigger, better favorite number: Write a program that asks for a person's favorite number. Have your program add 1 to the number, and then suggest the result as a bigger and better number.

puts "What is your favorite number?"
favenum = gets.chomp.to_i
puts "Cool number, but #{favenum + 1} is bigger and better."

# -------------------------------------------
