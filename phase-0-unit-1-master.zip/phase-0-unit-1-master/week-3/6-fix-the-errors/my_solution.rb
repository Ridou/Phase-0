# --- error -------------------------------------------------------

# "Screw you guys" + "I'm going home"	= cartmans_phrase

# (1) what is the name of the file with the error?
# => my_solution.rb
# (2) what is the line number where the error occurs?
# => 3
# (3) what is the error message?
# => syntax error, unexpected '=', expecting end-of-input
# (4) what is ruby telling you is causing the error?
# => unexpected '='
# (5) what is the 'type' of the error?
# => syntax error

# --- error -------------------------------------------------------

# def cartman_hates_rainbows
#   while true
#     puts "What's there to hate about rainbows?"
# end


# (1) what is the name of the file with the error?
# => my_solution.rb
# (2) what is the line number where the error occurs? 
# HINT: The line number is deceiving with this one. 
# => 174
# (3) what is the error message?
# => syntax error, unexpected end-of-input, expecting keyword_end
# (4) what is ruby telling you is causing the error?
# => expecting an end at the ending of the solution
# (5) what is the 'type' of the error?
# => syntax error

# --- error -------------------------------------------------------

#south_park

# (1) what is the name of the file with the error?
# => my_solution.rb
# (2) what is the line number where the error occurs?
# => 39
# (3) what is the error message?
# => in '<main>': undefined local variable or method 'south_park' for main:Object (NameError)
# (4) what is ruby telling you is causing the error?
# => undefined local variable 'south_park'
# (5) what is the 'type' of the error?
# => NameError

# --- error -------------------------------------------------------

# cartman()

# (1) what is the name of the file with the error?
# => my_solution.rb
# (2) what is the line number where the error occurs?
# => 54
# (3) what is the error message?
# => in '<main>': undefined method 'cartman' for mainObject (NoMethodError)
# (4) what is ruby telling you is causing the error?
# => undefined method 'cartman'
# (5) what is the 'type' of the error?
# => NoMethodError

# --- error -------------------------------------------------------

# def cartmans_phrase
#   puts "I'm not fat; I'm big-boned!"
# end

# cartmans_phrase('I hate Kyle')

# (1) what is the name of the file with the error?
# => my_solution.rb
# (2) what is the line number where the error occurs?
# => 68
# (3) what is the error message?
# => in 'cartmans_phrase': wrong number of arguments (1 for 0) (ArgumentError)
# (4) what is ruby telling you is causing the error?
# => wrong number of arguments
# (5) what is the 'type' of the error?
# => ArgumentError

# --- error -------------------------------------------------------

# def cartman_says(offensive_message)
#   puts offensive_message
# end

# cartman_says

# (1) what is the name of the file with the error?
# => my_solution.rb
# (2) what is the line number where the error occurs?
# => 87
# (3) what is the error message?
# => in 'cartman_says': wrong number of arguments (0 for 1) (Argument Error)
# (4) what is ruby telling you is causing the error?
# => wrong number of arguments
# (5) what is the 'type' of the error?
# => ArgumentError




# --- error -------------------------------------------------------

# def cartmans_lie(lie, name)
#   puts "#{lie}, #{name}!"
# end

# cartmans_lie('A meteor the size of the earth is about to hit Wyoming!')

# (1) what is the name of the file with the error?
# => my_solution.rb
# (2) what is the line number where the error occurs?
# => 109
# (3) what is the error message?
# => in 'cartmans_lie': wrong number of arguments (1 for 2) (ArgumentError)
# (4) what is ruby telling you is causing the error?
# => wrong number of argument 1 of 2 
# (5) what is the 'type' of the error?
# => ArgumentError


# --- error -------------------------------------------------------

# 5 * "Respect my authoritay!"

# (1) what is the name of the file with the error?
# => my_solution.rb
# (2) what is the line number where the error occurs?
# => 129
# (3) what is the error message?
# => in '*': String can't be coerced into Fixnum (TypeError)
# (4) what is ruby telling you is causing the error?
# => String cannot be coerced into fix num. Cannot multiply a number times a string.
# (5) what is the 'type' of the error?
# => TypeError

# --- error -------------------------------------------------------

# amount_of_kfc_left = 20/0

# (1) what is the name of the file with the error?
# => my_solution.rb
# (2) what is the line number where the error occurs?
# => 144
# (3) what is the error message?
# => '/': divided by 0 (ZeroDivisionError)
# (4) what is ruby telling you is causing the error?
# => math error cannot divide by 0
# (5) what is the 'type' of the error?
# => ZeroDivisionError

# --- error -------------------------------------------------------

# require_relative "cartmans_essay.md"

# (1) what is the name of the file with the error?
# => my_solution.rb
# (2) what is the line number where the error occurs?
# => 159
# (3) what is the error message?
# => in 'require_relative': cannot load such file -- /Users/richardsantin/Documents/DBCGits/phase-0-unit-1/week-3/6-fix-the-errors/cartmans_essay.md (LoadError)
# (4) what is ruby telling you is causing the error?
# => The file cannot be loaded
# (5) what is the 'type' of the error?
# => LoadError


# --- REFLECTION -------------------------------------------------------
# These exercises were very educational. 
# I feel more confident reading errors and now after good practice.
# I understand every part of reading and interpreting the errors in the terminal.
