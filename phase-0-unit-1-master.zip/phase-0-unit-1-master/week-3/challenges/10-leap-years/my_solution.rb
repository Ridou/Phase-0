# U1.W3: Leap Years

# I worked on this challenge [by myself, with: Lele].


# Your Solution Below
# 
def leap_year?(year)
  if (year % 4 == 0)
    return true unless (year % 100 == 0) && (year % 400 != 0)
    false
  else
    false
  end
end