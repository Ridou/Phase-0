# U1.W3: Define an Empty Method

# I worked on this challenge [by myself, with: ].


# Your Solution Below

def do_something(cool, story, bro)
end
