# U1.W3: Good Guess

# I worked on this challenge [by myself, with: Lele].


# Your Solution Below

def good_guess?(integer)
  return integer == 42
end