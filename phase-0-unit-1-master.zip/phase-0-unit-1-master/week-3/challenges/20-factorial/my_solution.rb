# U1.W3: Factorial

# I worked on this challenge [by myself, with: Lele].


# Your Solution Below
def factorial(number)
  foo = 1
  for i in (1..number)
    foo = foo * i
  end
  return foo
end