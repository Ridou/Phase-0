# U1.W3: Calculate a Grade

# I worked on this challenge [by myself, with: ].


# Your Solution Below

def get_grade(x)
  case x
    when 90..100 then "A"
    when 80..89 then "B"
    when 70..79 then "C"
    when 60..69 then "D"
    when 0..59 then "F"
  end
end