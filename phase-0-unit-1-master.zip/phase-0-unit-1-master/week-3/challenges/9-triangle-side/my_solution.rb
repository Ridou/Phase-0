# U1.W3: Triangle Side

# I worked on this challenge [by myself, with: ].


# Your Solution Below

def valid_triangle?(a, b, c)
  (a + b > c) && (a + c > b) && (b + c > a)
end
