# U1.W3: Simple Substrings

# I worked on this challenge [by myself, with: ].


# Your Solution Below

def welcome(address)
	if address.include? "CA"
		"Welcome to California"
	else
		"You should move to California"
	end
end