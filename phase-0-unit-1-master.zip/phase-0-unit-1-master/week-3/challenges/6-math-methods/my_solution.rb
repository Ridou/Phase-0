# U1.W3: Math Methods

# I worked on this challenge [by myself, with: ].


# Your Solution Below

def add(num_1, num_2)
 num_1 + num_2
end

def subtract(num_1, num_2)
 num_1 - num_2
end

def multiply(num_1, num_2)
 num_1 * num_2
end

def divide(num_1, num_2)
 num_1.to_f / num_2.to_f
end