# U1.W3: Format an Address

# I worked on this challenge [by myself, with: ].


# Your Solution Below

def make_address(street, city, state, zip)
  zip = zip.to_s
  return "You live at #{street}, in the beautiful city of #{city}, #{state}. Your zip is #{zip}."
end