# 8. Creating your website Reflection

My Website url:
<!-- Place your website link here -->

Discuss the following:
* What did you learn about design and user experience?
* Do you like design and user experience? Was it fun working on your site, the plan, and/or the wireframe? (If you hated it, that's OK too)
* What was your process? What worked and didn't work?
* What would you like to add or change about the site next?
* Was it difficult to apply the material you learned? Did you find anything in your research you thought was super cool?
* What else do you want to build? Make a list to check back on later!
* Did you find any resources on your own that helped you better understand a topic? If so, please list it.
