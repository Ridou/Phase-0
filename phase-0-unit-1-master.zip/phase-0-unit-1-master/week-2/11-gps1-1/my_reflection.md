## 11. GPS 1.1 Reflection

- What git concepts were you struggling with prior to the GPS session?
- What was clarified during the GPS?
- What (if anything) was made more confusing?
- How was your first experience of pairing in a guided pairing session?
- Was having a guide there intimidating? helpful? reassuring?
- What were your 'aha' moments?

1. I was new to git, but I struggled a bit with the git workflow
2. I had questions about git pull and git merge. I wanted to do a pull request from the terminal.
3. The GPS clarified all my questions.
4. I enjoyed it and we paired 2 days before to get a feel of the pairing session.
5. It was helpful and insightful.
6. Pull request through github and using markdown language.