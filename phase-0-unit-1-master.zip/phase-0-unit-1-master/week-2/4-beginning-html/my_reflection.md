## 4. Beginning HTML Reflection

- What makes sense to you about HTML? What doesn't?
- What seems good and bad about HTML?
- Did you have any "aha" moments where any concepts solidified? What were they?
- Did you have any previous experience with HTML/CSS? If so, how much? If not, how hard did you feel it was to learn?
- Did you find any resources on your own that helped you better understand a topic? If so, please list them.

1. Most of HTML 5 makes sense but I usually get a bit confused when I am working with a container inside a div that is inside another div. It can get confusing if I don't organize myself.
2. HTML5 is the language that most people learn when they are young and it seems to be the most user friendly until I found out about Ruby. Not many bad things about HTML5 just that you can't make things move without Javascript or Ruby.
3. Working with unordered lists is tricky and it was solidified.
4. Yes, I have experience with HTML5 for 5 years.
5. The links that were supplied on this challenge were good enough
