# U1.W2: Mood Board Reflection

* What elements did you choose for your mood board? Why?
* How did they help you plan out your website?
* What tools did you use to make your mood board?