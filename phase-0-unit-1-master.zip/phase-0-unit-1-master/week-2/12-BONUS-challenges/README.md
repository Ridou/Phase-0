Each of these challenges is optional, but beneficial to your learning.

- [Intermediate HTML and CSS](intermediate-html-css)
- [Responsive Design](responsive-design)
- [Mood Board and Design](mood-board)