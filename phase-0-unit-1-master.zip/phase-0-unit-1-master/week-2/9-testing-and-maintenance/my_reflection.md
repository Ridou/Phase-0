## 9. Testing and Maintenance Reflection

Include images of your maintenance schedule (inline, using markdown) below:

Schedule: Monday ~6:00PM

***
1. While testing, did you find any errors in your code? How did you handle them?
2. Did you receive any particularly helpful feedback? Why was it helpful?
3. How do you plan to incorporate the feedback you received?

1. Not any serious errors just typos.
2. Yes, a helpful feedback was to add a calendar to be able to schedule appointments with people that look at my blog.
3. I added Google Calendar iframe to the website and will continue to polish the website to make it look good.