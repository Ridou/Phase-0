## 6. Blog Template Challenge Reflection

- What concepts are you having trouble with, or did you just figure something out? If so, what?
- Did you learn any new skills or tricks?
- How confident are you with each of the Learning Competencies for this challenge?
- Which parts of the challenge did you enjoy?
- Which parts of the challenge did you find tedious?

1. I was having trouble linking the CSS with my HTML although I type the anochor tag correctly. I took a nap and got back into it and figured it out.
2. I had done most of it before and I just polished my skills
3. "I get it, I get it" - Drake
4. I enjoyed working with someone to create a template and combining elements from both wireframes.
5. I was stuck with a simple part and it was tedious because it slowed me down. It was fun though.