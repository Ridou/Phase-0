# 7. Chrome Dev Tools Challenge Reflection

## Release 1: Chrome Dev Tools

![codeschool1](../imgs/codeschool1.png)

![codeschool2](../imgs/codeschool2.png)

![codeschool3](../imgs/codeschool3.png)



## Release 2: Positioning

- New Colors:

![part1](../imgs/part1.png)

- Boxes in a row

![part2](../imgs/part2.png)

- Make the boxes have equal distance between them

![part3](../imgs/part3.png)

- Move all the boxes into one column

![part4](../imgs/part4.png)

- Resize the boxes so they are 30% of their original size

![part5](../imgs/part5.png)

- Make the static div go to the bottom and have an absolute positiion (no matter what, it should always be at the bottom of the page - but not in the browser window) Make the footer 100% the width of the screen

![part6](../imgs/part6.png)

- Make the absolute div a header at the top of the page with a fixed position so it's always at the top of the browser window. Make the width 95% of the entire screen and centered

![part7](../imgs/part7.png)

- Move the relative div position to the right so it's like a right sidebar.

![part8](../imgs/part8.png)

- Make a configuration that plays with margin, border, and padding. See if you can find a quick way to explain that to yourself.

![part9](../imgs/part9.png)

- Make a configuration that uses block and inline-block to see what the differences are

![part9](../imgs/part9.png)

## Release 3: Reflection
<!-- Remember, reflections should only take about 10-15 minutes to write -->
* Describe the Document Object Model. What about it makes sense to you? What doesn't? What seems good and bad about it?
* Did you find Chrome Web Tools fun, helpful, or a pain to work with?
* Did you have an "aha" moments or were any concepts solidified?

1. The Document Object Model is a virtual map of the HTML. Something like a structured tree of different nested parent and children elements. It is confusing when there are DOM's inside DOM's and wanting to work on them.
2. I didn't like Chrome Web Tools that much. I much rather would use Firebug from Firefox. I am more comfortable with the interface.
3. Yes, while using positioning and floating I had a couple aha! moments. I also did all the courses from codeschool to the realize I only needed the first two, ohh well more knowledge can't hurt.
