## 2. Site Planning Reflection

*Remember, reflections should only take about 10-15 minutes.*

### Site planning

1. What is your site's primary goal or purpose?
2. What kind of content will your site feature?
3. What is the best way to share that content with users?
4. Think about your target audience. What are their interests and how do you see your site addressing them?
5. How do you think most users will find your site?
6. What is the primary "action" the user should take when coming to your site? Do you want them to search for information, contact you, or see your portfolio? It's ok to have several actions at once, or different actions for different kinds of visitors.

***

### Site map

Your site map:

![site-map](../imgs/site-map.png)

- What did you learn about design and user experience?
- Do you like design and user experience? Was it fun planning your site and creating a site map? (If you hated it, that's OK too)
- What questions did you ask during this challenge? What resources did you find to help you answer them?
- What concepts are you having trouble with, or did you just figure something out? If so, what?
- How confident are you with each of the Learning Competencies for this challenge?
- Which parts of the challenge did you enjoy?
- Which parts of the challenge did you find tedious?

### Site Planning Response

1. The purpose of this site is to share my experience while attending DevBootCamp.
2. This website will feature a blog, a portfolio and a way to contact the author.
3. The best way to share the content to users is utilizing social media networks.
4. The target audience will be those that are thinking of attending, are currently attending, attended and future friends that are interested in my experience in DevBootCamp while learning Ruby. To get the full feel of the experience I will post pictures and videos in the blogs to immerse them in my experience.
5. Most users will find the site by either knowing me or being interested in joining DevBootCamp and googling it.
6. They will read the blog, watch the video/pictures, read the portfolio for a more technical insight and contact me for feedback.

### Site Map Response
1. There are many different type of people and to create a good design is to make it what you see is what you get, that way the user can comfortably guide through the website like if it was second nature.
2. I love designing and user experience. Yes it was fun although it is simple I have never done a "blog" or "vlog".
3. When my friends or human resources managers wanted to know about me, what is the best way to share my personality and my experience as a developer.
4. I'm not used to writing a diary or a blog, so just the concept of writing about myself and expressing my full experience in words/videos/pictures will be difficult.
5. I think the learning competencies are amazing! Very professional and organized. Good job DevBootCamp team!
6. I enjoyed it fully.

