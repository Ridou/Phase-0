## 5. Beginning CSS Reflection

- What makes sense to you about CSS? What doesn't?
- What seems good and bad about CSS?
- Did you have any "aha" moments or were any concepts solidified?
- Did you have any experience before with HTML/CSS? If so, how much? If not, how hard did you feel it was to learn?
- When you looked at Berkshire Hathaway's source code, what were your first impressions of their code?
- Which site followed best practices based on what you know about best practices?

1. CSS is an effective way to style HTML, sometimes I have trouble with the positioning.
2. The good thing is that you can use it to improve the looks of the site, the bad is that you cannot use flash or java effectively.
3. Yes, I had a couple because I went back to the language from not using it in a couple of months.
4. Yes, I had experience and about 5 years.
5. Slow, why would they put all their code in the HTML. It isn't much information but it would work more efficiently if it loaded the CSS first and then seperated the divs.
6. W3 schools has been my reference page for HTML.