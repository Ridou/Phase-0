[Week 2 Home](./)

# U1.W2: Cultural Assignment

## Learning Competencies
- Practice sharing vulnerability with the people in your cohort
- Identify your biggest fear
- Describe what you would tell your friend if they shared a fear with you

## Release 0: Consider the question:
**What scares you the most about being at DBC?**

## Release 1: Email your cohort
Write an email to your cohort using your local cohort mailing list (available on your cohort page in Socrates under the name) that answers this question. Use the subject "Cultural Assignment" if you are the first person. Everyone should reply to the original thread.

If you are the second or later, **REPLY ALL** with your response. Be sure to do this by **Wednesday**.

## Release 2: Reply to your cohort-mates
Starting **Thursday**, take a look at your cohort-mates responses and choose one to respond to. Pretend your best friend is saying that to you. How would you respond? Make sure to direct your response to that person. Reply all to the original thread with your response.

## Release 3: Read your cohort-mates' responses!

## Release 4: Submit
You'll be asked to submit your responses on the weekly submission form.