## 3. Wireframing Reflection
*Remember, reflections should only take about 10-15 minutes.*

Include images of your wireframe (inline, using markdown) below:

Index/Blog/Portfolio Wireframe:

![wireframe](../imgs/wireframe.png)

***

- Did you enjoy wireframing your site?
- Did you find yourself revising your wireframe often? Or did you stick with your first idea?
- What questions did you ask during this challenge? What resources did you find to help you answer them?
- What concepts are you having trouble with?
- Did you learn any new skills or tricks?
- How confident are you with each of the Learning Competencies for this challenge?
- Which parts of the challenge did you enjoy?
- Which parts of the challenge did you find tedious?

1. Yes, I enjoyed it.
2. I had many ideas of how I wanted to make the site and used the most efficient.
3. In which way can I make the navigation more convenient where all the information is easily accessible in the site.
4. Very good resources made it easy to learn.
5. I learned how to create a wireframe on the computer, because I have a notebook that I create lots of different ideas. I still believe it is safer because what is in the internet stays there.
6. The challenges were a lot of fun and I see myself using this tool to wireframe.
7. I enjoyed reading, creating the wireframe was user friendly and writing in sublime.
8. It was fun!
